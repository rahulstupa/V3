// response.addHeader("Access-Control-Allow-Origin", "*");
import {gsap} from "gsap@npm:gsap-trial"
// import gsap from "../gsap-trial";
// import DrawSVGPlugin from "./gsap-trial/DrawSVGPlugin";
// gsap.registerPlugin(ScrollTrigger, DrawSVGPlugin,CssPlugin);